import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { Activity } from "lucide-react";

interface DiabetesPredictionProps {
  onPrediction: (result: any) => void;
}

const DiabetesPrediction = ({ onPrediction }: DiabetesPredictionProps) => {
  const [formData, setFormData] = useState({
    glucose: "",
    bloodPressure: "",
    skinThickness: "",
    insulin: "",
    bmi: "",
    diabetesPedigree: "",
    age: "",
    pregnancies: ""
  });

  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    // Simulate API call
    setTimeout(() => {
      const prediction = Math.random();
      const riskLevel = prediction > 0.7 ? 'high' : prediction > 0.4 ? 'medium' : 'low';
      
      const result = {
        disease: 'Diabetes',
        probability: prediction * 100,
        riskLevel,
        shapValues: [
          { feature: 'Glucose Level', value: parseFloat(formData.glucose) || 0, impact: 0.25 },
          { feature: 'BMI', value: parseFloat(formData.bmi) || 0, impact: 0.18 },
          { feature: 'Age', value: parseFloat(formData.age) || 0, impact: 0.15 },
          { feature: 'Blood Pressure', value: parseFloat(formData.bloodPressure) || 0, impact: 0.12 },
          { feature: 'Insulin', value: parseFloat(formData.insulin) || 0, impact: 0.10 }
        ],
        recommendations: riskLevel === 'high' 
          ? [
              'Immediate consultation with endocrinologist recommended',
              'Monitor blood glucose levels daily',
              'Implement strict dietary modifications',
              'Increase physical activity under medical supervision'
            ]
          : riskLevel === 'medium'
          ? [
              'Schedule follow-up appointment in 3 months',
              'Monitor blood glucose levels weekly',
              'Maintain healthy diet and exercise routine',
              'Consider lifestyle modifications'
            ]
          : [
              'Continue regular health checkups',
              'Maintain current lifestyle',
              'Monitor for any symptom changes',
              'Annual diabetes screening recommended'
            ]
      };

      onPrediction(result);
      setIsLoading(false);
    }, 2000);
  };

  const handleChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <Label htmlFor="glucose">Glucose Level (mg/dL)</Label>
          <Input
            id="glucose"
            type="number"
            placeholder="e.g., 140"
            value={formData.glucose}
            onChange={(e) => handleChange('glucose', e.target.value)}
            required
          />
        </div>
        <div>
          <Label htmlFor="bloodPressure">Blood Pressure (mmHg)</Label>
          <Input
            id="bloodPressure"
            type="number"
            placeholder="e.g., 80"
            value={formData.bloodPressure}
            onChange={(e) => handleChange('bloodPressure', e.target.value)}
            required
          />
        </div>
        <div>
          <Label htmlFor="bmi">BMI (kg/m²)</Label>
          <Input
            id="bmi"
            type="number"
            step="0.1"
            placeholder="e.g., 25.3"
            value={formData.bmi}
            onChange={(e) => handleChange('bmi', e.target.value)}
            required
          />
        </div>
        <div>
          <Label htmlFor="age">Age (years)</Label>
          <Input
            id="age"
            type="number"
            placeholder="e.g., 45"
            value={formData.age}
            onChange={(e) => handleChange('age', e.target.value)}
            required
          />
        </div>
        <div>
          <Label htmlFor="insulin">Insulin Level (μU/mL)</Label>
          <Input
            id="insulin"
            type="number"
            placeholder="e.g., 79"
            value={formData.insulin}
            onChange={(e) => handleChange('insulin', e.target.value)}
          />
        </div>
        <div>
          <Label htmlFor="pregnancies">Pregnancies</Label>
          <Input
            id="pregnancies"
            type="number"
            placeholder="e.g., 2"
            value={formData.pregnancies}
            onChange={(e) => handleChange('pregnancies', e.target.value)}
          />
        </div>
      </div>

      <Button 
        type="submit" 
        className="w-full bg-primary hover:bg-primary/90" 
        disabled={isLoading}
      >
        {isLoading ? (
          <div className="flex items-center gap-2">
            <Activity className="h-4 w-4 animate-spin" />
            Analyzing...
          </div>
        ) : (
          'Predict Diabetes Risk'
        )}
      </Button>
    </form>
  );
};

export default DiabetesPrediction;