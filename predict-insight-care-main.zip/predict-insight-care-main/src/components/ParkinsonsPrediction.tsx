import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Brain } from "lucide-react";

interface ParkinsonsPredictionProps {
  onPrediction: (result: any) => void;
}

const ParkinsonsPrediction = ({ onPrediction }: ParkinsonsPredictionProps) => {
  const [formData, setFormData] = useState({
    fo: "",
    fhi: "",
    flo: "",
    jitter: "",
    shimmer: "",
    nhr: "",
    hnr: "",
    rpde: "",
    dfa: "",
    spread1: "",
    spread2: "",
    d2: "",
    ppe: ""
  });

  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    // Simulate API call
    setTimeout(() => {
      const prediction = Math.random();
      const riskLevel = prediction > 0.6 ? 'high' : prediction > 0.3 ? 'medium' : 'low';
      
      const result = {
        disease: "Parkinson's Disease",
        probability: prediction * 100,
        riskLevel,
        shapValues: [
          { feature: 'Jitter (%)', value: parseFloat(formData.jitter) || 0, impact: 0.22 },
          { feature: 'Shimmer', value: parseFloat(formData.shimmer) || 0, impact: 0.18 },
          { feature: 'HNR', value: parseFloat(formData.hnr) || 0, impact: 0.16 },
          { feature: 'RPDE', value: parseFloat(formData.rpde) || 0, impact: 0.14 },
          { feature: 'DFA', value: parseFloat(formData.dfa) || 0, impact: 0.12 }
        ],
        recommendations: riskLevel === 'high' 
          ? [
              'Immediate neurological consultation recommended',
              'Comprehensive movement disorder evaluation',
              'Consider DaTscan imaging if clinically indicated',
              'Speech therapy assessment recommended'
            ]
          : riskLevel === 'medium'
          ? [
              'Schedule neurological follow-up in 6 months',
              'Monitor for progressive symptoms',
              'Voice and speech evaluation',
              'Regular movement assessment'
            ]
          : [
              'Continue routine health monitoring',
              'Annual neurological screening',
              'Maintain active lifestyle',
              'Report any new movement concerns'
            ]
      };

      onPrediction(result);
      setIsLoading(false);
    }, 2000);
  };

  const handleChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <Label htmlFor="fo">Average Vocal Fundamental Frequency</Label>
          <Input
            id="fo"
            type="number"
            step="0.001"
            placeholder="e.g., 154.228"
            value={formData.fo}
            onChange={(e) => handleChange('fo', e.target.value)}
            required
          />
        </div>
        <div>
          <Label htmlFor="jitter">Jitter (%)</Label>
          <Input
            id="jitter"
            type="number"
            step="0.00001"
            placeholder="e.g., 0.00662"
            value={formData.jitter}
            onChange={(e) => handleChange('jitter', e.target.value)}
            required
          />
        </div>
        <div>
          <Label htmlFor="shimmer">Shimmer</Label>
          <Input
            id="shimmer"
            type="number"
            step="0.001"
            placeholder="e.g., 0.031"
            value={formData.shimmer}
            onChange={(e) => handleChange('shimmer', e.target.value)}
            required
          />
        </div>
        <div>
          <Label htmlFor="nhr">Noise-to-Harmonics Ratio</Label>
          <Input
            id="nhr"
            type="number"
            step="0.001"
            placeholder="e.g., 0.024"
            value={formData.nhr}
            onChange={(e) => handleChange('nhr', e.target.value)}
            required
          />
        </div>
        <div>
          <Label htmlFor="hnr">Harmonics-to-Noise Ratio</Label>
          <Input
            id="hnr"
            type="number"
            step="0.001"
            placeholder="e.g., 21.033"
            value={formData.hnr}
            onChange={(e) => handleChange('hnr', e.target.value)}
            required
          />
        </div>
        <div>
          <Label htmlFor="rpde">RPDE</Label>
          <Input
            id="rpde"
            type="number"
            step="0.001"
            placeholder="e.g., 0.498"
            value={formData.rpde}
            onChange={(e) => handleChange('rpde', e.target.value)}
            required
          />
        </div>
        <div>
          <Label htmlFor="dfa">DFA</Label>
          <Input
            id="dfa"
            type="number"
            step="0.001"
            placeholder="e.g., 0.679"
            value={formData.dfa}
            onChange={(e) => handleChange('dfa', e.target.value)}
            required
          />
        </div>
        <div>
          <Label htmlFor="ppe">PPE</Label>
          <Input
            id="ppe"
            type="number"
            step="0.001"
            placeholder="e.g., 0.168"
            value={formData.ppe}
            onChange={(e) => handleChange('ppe', e.target.value)}
            required
          />
        </div>
      </div>

      <Button 
        type="submit" 
        className="w-full bg-primary hover:bg-primary/90" 
        disabled={isLoading}
      >
        {isLoading ? (
          <div className="flex items-center gap-2">
            <Brain className="h-4 w-4 animate-spin" />
            Analyzing...
          </div>
        ) : (
          "Predict Parkinson's Risk"
        )}
      </Button>
    </form>
  );
};

export default ParkinsonsPrediction;