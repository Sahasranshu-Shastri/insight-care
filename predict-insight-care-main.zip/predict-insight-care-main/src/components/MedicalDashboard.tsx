import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Activity, Brain, Heart, TrendingUp } from "lucide-react";
import DiabetesPrediction from "./DiabetesPrediction";
import ParkinsonsPrediction from "./ParkinsonsPrediction";
import PredictionResults from "./PredictionResults";

interface PredictionResult {
  disease: string;
  probability: number;
  riskLevel: 'low' | 'medium' | 'high';
  shapValues: Array<{ feature: string; value: number; impact: number }>;
  recommendations: string[];
}

const MedicalDashboard = () => {
  const [activeTab, setActiveTab] = useState<'diabetes' | 'parkinsons'>('diabetes');
  const [predictionResult, setPredictionResult] = useState<PredictionResult | null>(null);

  const handlePrediction = (result: PredictionResult) => {
    setPredictionResult(result);
  };

  const stats = [
    {
      title: "Total Predictions",
      value: "1,247",
      change: "+12%",
      icon: TrendingUp,
      color: "text-medical-blue"
    },
    {
      title: "Accuracy Rate",
      value: "94.2%",
      change: "+2.1%",
      icon: Activity,
      color: "text-medical-green"
    },
    {
      title: "Diabetes Cases",
      value: "823",
      change: "+8%",
      icon: Heart,
      color: "text-medical-accent"
    },
    {
      title: "Parkinson's Cases",
      value: "156",
      change: "+5%",
      icon: Brain,
      color: "text-medical-blue"
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-foreground mb-2">
            Disease Diagnosis Support System
          </h1>
          <p className="text-lg text-muted-foreground">
            AI-powered medical prediction with explainable insights
          </p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => {
            const Icon = stat.icon;
            return (
              <Card key={index} className="shadow-card hover:shadow-medical transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">
                        {stat.title}
                      </p>
                      <p className="text-2xl font-bold text-foreground">
                        {stat.value}
                      </p>
                      <Badge variant="secondary" className="mt-1">
                        {stat.change}
                      </Badge>
                    </div>
                    <Icon className={`h-8 w-8 ${stat.color}`} />
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Prediction Forms */}
          <div>
            <Card className="shadow-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Activity className="h-5 w-5 text-primary" />
                  Disease Prediction
                </CardTitle>
                <CardDescription>
                  Select a condition to analyze patient data and get AI-powered predictions
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex gap-2 mb-6">
                  <button
                    onClick={() => setActiveTab('diabetes')}
                    className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                      activeTab === 'diabetes'
                        ? 'bg-primary text-primary-foreground'
                        : 'bg-secondary text-secondary-foreground hover:bg-accent'
                    }`}
                  >
                    Diabetes
                  </button>
                  <button
                    onClick={() => setActiveTab('parkinsons')}
                    className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                      activeTab === 'parkinsons'
                        ? 'bg-primary text-primary-foreground'
                        : 'bg-secondary text-secondary-foreground hover:bg-accent'
                    }`}
                  >
                    Parkinson's
                  </button>
                </div>

                {activeTab === 'diabetes' && (
                  <DiabetesPrediction onPrediction={handlePrediction} />
                )}
                {activeTab === 'parkinsons' && (
                  <ParkinsonsPrediction onPrediction={handlePrediction} />
                )}
              </CardContent>
            </Card>
          </div>

          {/* Results */}
          <div>
            {predictionResult ? (
              <PredictionResults result={predictionResult} />
            ) : (
              <Card className="shadow-card h-full">
                <CardContent className="p-8 flex items-center justify-center h-full">
                  <div className="text-center">
                    <Brain className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
                    <h3 className="text-lg font-semibold text-foreground mb-2">
                      No Prediction Yet
                    </h3>
                    <p className="text-muted-foreground">
                      Complete a prediction form to see AI-powered results and explanations
                    </p>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default MedicalDashboard;