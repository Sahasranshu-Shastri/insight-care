import MedicalDashboard from "@/components/MedicalDashboard";
import heroImage from "@/assets/medical-hero.jpg";
import aiIcon from "@/assets/ai-medical-icon.jpg";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Brain, Shield, TrendingUp, Zap } from "lucide-react";

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-background to-muted py-20 overflow-hidden">
        <div className="absolute inset-0">
          <img 
            src={heroImage} 
            alt="Medical AI Dashboard" 
            className="w-full h-full object-cover opacity-10"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-background/90 to-background/70" />
        </div>
        
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-4xl mx-auto text-center">
            <Badge variant="secondary" className="mb-4">
              <Zap className="h-3 w-3 mr-1" />
              Powered by AI & Machine Learning
            </Badge>
            <h1 className="text-5xl md:text-6xl font-bold text-foreground mb-6">
              Disease Diagnosis 
              <span className="text-primary"> Support System</span>
            </h1>
            <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
              Advanced machine learning predictions for diabetes and Parkinson's disease 
              with explainable AI insights for clinical decision support.
            </p>
            
            <div className="flex flex-wrap justify-center gap-6 text-sm text-muted-foreground">
              <div className="flex items-center gap-2">
                <Brain className="h-4 w-4 text-primary" />
                PyTorch & XGBoost
              </div>
              <div className="flex items-center gap-2">
                <Shield className="h-4 w-4 text-primary" />
                SHAP Explainability
              </div>
              <div className="flex items-center gap-2">
                <TrendingUp className="h-4 w-4 text-primary" />
                94.2% Accuracy
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-16 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
            <Card className="shadow-card text-center">
              <CardContent className="p-8">
                <img 
                  src={aiIcon} 
                  alt="AI Icon" 
                  className="w-16 h-16 mx-auto mb-4 rounded-lg"
                />
                <h3 className="text-xl font-semibold mb-3">AI-Powered Predictions</h3>
                <p className="text-muted-foreground">
                  Advanced machine learning models trained on comprehensive medical datasets
                </p>
              </CardContent>
            </Card>
            
            <Card className="shadow-card text-center">
              <CardContent className="p-8">
                <Shield className="w-16 h-16 mx-auto mb-4 text-primary" />
                <h3 className="text-xl font-semibold mb-3">Explainable Results</h3>
                <p className="text-muted-foreground">
                  SHAP values provide transparent insights into prediction factors
                </p>
              </CardContent>
            </Card>
            
            <Card className="shadow-card text-center">
              <CardContent className="p-8">
                <TrendingUp className="w-16 h-16 mx-auto mb-4 text-primary" />
                <h3 className="text-xl font-semibold mb-3">Clinical Integration</h3>
                <p className="text-muted-foreground">
                  FastAPI microservice ready for clinical dashboard integration
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Dashboard */}
      <MedicalDashboard />
    </div>
  );
};

export default Index;
